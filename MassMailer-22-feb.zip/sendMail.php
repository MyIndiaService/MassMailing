<?php

require_once './swiftMailer/vendor/autoload.php';

	function send($to,$cc,$subject,$message)
	{
		// Create the Transport
		$transport = (new Swift_SmtpTransport('smtp.gmail.com', 465, 'ssl'))
		  ->setUsername('appstecamerica2@gmail.com')
		  ->setPassword('hitman25')
		;

		// Create the Mailer using your created Transport
		$mailer = new Swift_Mailer($transport);

		// Create a message
		$message = (new Swift_Message($subject))
		  ->setFrom(['narsingh@myindiaservice.com' => 'Appstech America'])
		  ->setTo([$to, $cc => 'Teqhub'])
		  ->setBody([$message =>'text/html'])
		  ;

		// Send the message
		if($mailer->send($message)==true)
		{
			echo "send successfully";
			return true;
		}
		else
		{
			echo "Failure to send the mail";
			return false;
		}
		
	}

?>