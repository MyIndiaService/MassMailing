<?php
$con=mysqli_connect("localhost","root","","dbnmassmail") or die (mysqli_info());
//mysql_select_db("dbnmassmail",$con);
?>