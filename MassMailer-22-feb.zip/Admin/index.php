<?php

echo "Invalid Access ! Error 404 Page not Found.";

?>