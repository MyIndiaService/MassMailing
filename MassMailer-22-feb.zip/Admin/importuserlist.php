		<?php		

		    $conn= mysqli_connect('localhost','root','','dbnmassmail');
		
			if(isset($_POST['submit']))
			{
				
				$fname=$_FILES['tname']['name'];
				echo 'upload file name'. $fname.'';
				$strArry = explode(".",$fname); 
				if(strtolower(end($strArry)== "csv"))
				{
					$filename=$_FILES['tname']['tmp_name'];
					$count=1;
					$handle=fopen($filename, "r");
					while(($data=fgetcsv($handle,1000,","))!==FALSE)
					{
						if($count!=1)
						{
							$chkdata="select name, email from mailerlist where name='".$data[0]."' and email='".$data[1]."'";
							$res=mysqli_query($conn,$chkdata) or die(mysqli_info($conn));
							$row=mysqli_fetch_object($res);
							if(!$row)
							{
								$sql="INSERT INTO mailerlist(name,email) VALUES ('".$data[0]."','".$data[1]."')";
								//echo $sql;
								$run=mysqli_query($conn,$sql) or die(mysqli_info($conn));
							}
						}
						$count++;

					}
					fclose($handle);
					echo "successfully imported";
				}
				else
				{
					echo "invalid file";
				}
			}
		?>

	<div style="height:inherit;width:inherit;padding:0px;text-align:left;">
		<form style="padding-left: 100px;padding-top: 50px" method="post" enctype="multipart/form-data">
	        <h3><u>Note:</u><i>Only Import CSV File</i></h3>
		  	Select CSV File:
          	<input type="file" name="tname"/>
            <input type="submit" value="submit" name="submit"/>
		</form>
    </div>

    