<?php


  $lines = file_get_contents('https://www.tutorialspoint.com/');
   echo $lines;

?>