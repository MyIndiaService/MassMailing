<?php
$con = mysqli_connect("localhost","root","","mmdbname") or die(mysqli_error());// replace dbuser, dbpass with your db user and password

$sno = (integer)$_GET['id'];
$email = mysql_real_escape_string($_GET['username']);

$query = "update subscribe_user set sub_status = 'UNSUBSCRIBED' where sno = $sno and email = '$email'";
mysql_query($con,$query) or die(mysqli_error());
echo "You have Successfully unsubscribed. Thank you for using the service.";
?>