<?php

	require 'phpmailer/PHPMailerAutoload.php';
	require 'dbConnect.php';
	require 'Model_Function.php';
	//SOURCE: http://thedigilife.com/bulk-email-script-in-php-and-mysql-database/

	$status="SUBSCRIBED";
	$query = "select sno, email from mailer_list where subscriber_status = '".$status."'";
	$result = mysqli_query(getConnection(),$query) or die(mysqli_error());
	if (!$result) {
	        echo 'MySQL Error: ' .mysqli_error();
	        exit;
	    }
	$emails = array();
	$sno = array();
	while($row=mysqli_fetch_assoc($result)){
		$sno[] = $row['sno']; // this will be used to unsubscribe the user
		$emails[]=$row['email']; // email id of user
	}
	$count =  file_get_contents("count.txt");
	//for($i=$count;$i<count($emails);$i++)
	for($i=0;$i<count($emails);$i++)
	{
		$to  = $emails[$i];
		$subject = 'Set Your Title Here';
		$message="Try to send some message for learning pourpose Randomly select mail id ";
		$message = file_get_contents("sample.html"); // this will get the HTML sample template sample.html
		$message .= '<p><a href="./unsubscribe.php?id='.$sno[$i].'&username='.$emails[$i].'">Please click here to unsubscribe.</a></p>
		</body>
		</html>';

			// To send HTML mail, the Content-type header must be set
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$headers.='From: narsingh@myindiaservice.com';
		$mail=new Model_Function();
		if($mail->sendMail($to, $subject, $message,$headers)) {
			$file = fopen("mailsentlist.txt","a+"); // add email id to mailsentlist.txt to track the email sent
			fwrite($file, $to.",\r\n");
			fclose($file);
		}
		else
		{
			$file = fopen("notmailsentlist.txt","a+"); // add email to notmailsentlist.txt here which have sending email error
			fwrite($file, $to.",\r\n");
			fclose($file);
		}
		if(($i-$count)>=5) // this will send 200 mails from database per execution
		{	
			$filec = fopen("count.txt",'w'); // store current count to count.txt
			fwrite($filec, $i);
			fclose($filec);
			break;
		}
	}//for end
	$filec = fopen("count.txt",'w'); // store fine count to count.txt this will be used as a start point of next execution
	fwrite($filec, $i);
	fclose($filec);

?>
