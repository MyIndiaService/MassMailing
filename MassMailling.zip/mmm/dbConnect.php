
<?php

	function getConnection()
	{
		$con = mysqli_connect("localhost","root","","massmailing") or die(mysqli_error());
		return $con;
	}


?>