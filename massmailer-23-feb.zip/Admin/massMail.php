<!--Select the User Type To Mail:  Select User type form userType Table and pick all the userList from userInfo table and Mail to them  
Subject:
Message:
Select HTML File as body part:
Attachment:
 -->
<?php

include_once('connection.php');
require_once('sendMail.php');

@$to=$_POST['to'];
@$sub=$_POST['sub'];
@$msg=$_POST['msg'];
@$cc=$_POST['cc'];
if($cc=="")
	$cc='narsingh@myindiaservice.com';
$file=$_FILES['file']['name'];

$id=$_SESSION['sid'];

if(@$_REQUEST['send'])
{
	if($to=="" || $sub=="" || $msg=="")
	{
	$err= "fill the related data first";
	}
	
	else
	{
		if($to=="UTALL")
			$data=mysqli_query($con,"SELECT * FROM mailerlist");
		else
			$data=mysqli_query($con,"SELECT * FROM mailerlist where typeId='".$to."'");
		
    	$count=mysqli_num_rows($data);
        while($row=mysqli_fetch_array($data,MYSQLI_ASSOC))
    	{
    		$to= $row['email'];
    		$message="Hello\r\n      ".$row['name']."\r\n";
    		$getContentofHtml=file_get_contents('abc.html');
    		$message.=$msg;
    		$message.=$getContentofHtml;
    		if(send($to,$cc,$sub,$message))
			{
				mysqli_query($con,"INSERT INTO usermail values('','$to','$id','$sub','$message','',sysdate())");
				$err= "message sent...";
			}
			else
			{
				$sub=$sub."--"."msg failed";
				mysqli_query($con,"INSERT INTO usermail values('','$id','$id','$sub','$message','',sysdate())");
				$err= "message failed...";
			}	
    	}
	}
}	

if(@$_REQUEST['save'])
{
	if($sub=="" || $msg=="")
	{
	$err= "<font color='red'>fill subject and msg first</font>";
	}
	
	else
	{
	$query="INSERT INTO draft values('','$id','$sub','$file','$msg',sysdate())";
	mysqli_query($con,$query);
	$err= "message saved...";
	}
}	

$optionId="<option value=''>--Plz Select --</option>";
		//fucntion getUserTypeId(){
			$conn=mysqli_connect('localhost','root','',dbnmassmail);
			$query="SELECT typeId FROM usertype";
			$run=mysqli_query($conn,$query);
			//globals $optionId;
			while($row=mysqli_fetch_array($run,MYSQLI_ASSOC))
			{
				$optionId=$optionId."<option value=".$row[typeId].">".$row[typeId]."</option>";
			} 
			//return $optionId;
	//	}
		
	?>
<head>
	<style>
	input[type=text]
	{
	width:200px;
	height:35px;
	}
	</style>
</head>
<body>
<form method="post" enctype="multipart/form-data">
<table width="506" border="1">
  <?php echo @$err; ?>
  <tr>
    <th width="213" height="35" scope="row">To</th>
    <td width="277">
		<select name="to">
			<?php echo $optionId;		 ?>   
	 	</select>
	</td>
  </tr>
  <tr>
    <th height="36" scope="row">Cc</th>
    <td><input type="text" name="cc"/></td>
  </tr>
  <tr>
    <th height="36" scope="row">Subject</th>
    <td><input type="text" name="sub" /></td>
  </tr>
  <tr>
    <th height="36" scope="row">upload your file</th>
    <td><input type="file" name="file" id="file"/></td>
  </tr>
  <tr>
    <th height="52" scope="row">Msg</th>
    <td><textarea rows="8" cols="40" name="msg"></textarea></td>
  </tr>
  <tr>
    <th height="35" colspan="2" scope="row">
	<input type="submit" name="send" value="Send"/>
	<input type="submit" name="save" value="Save"/>
	<input type="reset" value="Cancel"/>	</th>
  </tr>
</table>

</body>
</form>
</html>

