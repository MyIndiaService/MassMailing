<?php

	function getConnection()
	{
		
		$conn=mysqli_connect('localhost','root','','massmailer');
		return $conn;
	}
	
	if(isset($_REQUEST['add']))
	{
		$tname=$_REQUEST['typeId'];
		$temail=$_REQUEST['typeofuser'];
		$textarea=$_REQUEST['textarea'];

		$query="insert into manage(tname,typeOfUser,textarea) values('".$typeId."','".$typeofuser."','".$textarea."')";
		$run=mysqli_query(getConnection(),$query);
	}
	if(isset($_REQUEST['remove']))
	{
		$tname=$_REQUEST['typeId'];
		$temail=$_REQUEST['typeofuser'];
		$textarea=$_REQUEST['textarea'];
		$query1="delete from manage where temail='".$temail."' ";
		$run1=mysqli_query(getConnection(),$query1);
	}
	 if(isset($_REQUEST['update']))
	{    
		$tname=$_REQUEST['typeId'];
		$temail=$_REQUEST['typeofuser'];
		$textarea=$_REQUEST['textarea'];
		$query2="UPDATE manage SET tname='".$typeId."',textarea='".$textarea."' where temail='".$typeofuser."' ";
		
		if (!mysqli_query(getConnection(),$query2))
	    {
	  		echo("Error description: " . mysqli_error(getConnection()));
	    }

	}
	if(isset($_REQUEST['find']))
	{
		$tname=$_REQUEST['typeId'];
		$temail=$_REQUEST['temail'];
		$textarea=$_REQUEST['textarea'];
			// Select statement
			$search ="SELECT * FROM manage WHERE temail ='".$typeofuser."' ";
			$result=mysqli_query(getConnection(),$search);

						if ($result->num_rows > 0) 
						{
						    echo "<table><tr><th>ID</th><th>Email</th><th>Message</th></tr>";
						    // output data of each row
						    while($row = mysqli_fetch_array($result,MYSQLI_NUM)) 
						    {
						        echo "<tr><td>".$row[0]."</td><td>".$row[1]." ".$row[2]."<td>".$row[3]."</td></tr>";
						    }
						    echo "</table>";
						} else {
						    echo "0 results";
						}
	} 

?>

<div style="height:inherit;width:inherit;padding:0px;text-align:left;">
	 <form style="padding-left: 100px;padding-top: 50px">
        <table>
        	<tr>
        		<td>
       				 Type of id:
        		</td>
        		<td>
        			<input type="text" name="typeId" placeholder="Enter Id type"/>
        		</td>
        	</tr>
        	<tr>
       			<td>	    
       			 	Type of User:
        		</td>
        		<td>
       				 <input type="email" name="typeofuser" required placeholder="Enter user type eg subs,unsubs"/>
       
        		</td>
    			</tr>
   				 <tr>
    				<td>
	    				Description:
					</td>
					<td>
						<textarea rows="10" col="10" name="textarea" placeholder="Discription"></textarea>
					</td>
				</tr>
		</table>
		
			
				<input type="submit" value="Add" name="add" />
			    <input type="submit" value="Remove" name="remove" />
			    <input type="submit" value="Update" name="update" />
			    <input type="submit" value="Find" name="find" />
			
	    					 
	</form>
</div>
     

