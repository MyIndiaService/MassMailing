
<?php
	session_start();

	
	if(isset($_SESSION['aname']))
		{
	
 ?>
	<html>
		<head>
			<title>Logout</title>
		</head>
	<body align="center" style="background-color:lightyellow; margin-top:2cm">
		
			<H1><?php echo "thanks for visiting"; ?></H1>
	</body>
	</html>		
<?php
			session_destroy();
			header('Refresh:3; url=../index.php');
		}
	else                    
		{
			header('location:../index.php');
		}
	
?>